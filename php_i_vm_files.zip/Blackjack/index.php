<?php

/**
 * Web Blackjack
 * 
 * THIS CODE IS INTENDED FOR DEMOSTRATION AND TRAINING PURPOSES ONLY
 * FOR PARTICIPANTS OF THE ZEND TECHNOLOGIES PHP FOUNDATIONS COURSE.
 * THIS CODE IS NOT OPEN SOURCE, AND UNAUTHORIZED USE IS PROHIBITED.
 * 
 * @copyright (c) 2007 Zend Technologies, All Rights Reserved
 */


require_once 'library.inc.php';

// Display the header for the game, includes the header HTML
displayHeader();

// Start a session to persist the game betweeen web requessts
session_start();

// If we haven't created a deck yet (includes starting hands),
// do so by calling the getNewHand() function
if(!isset($_SESSION['deck'])) {
	list($_SESSION['dealer'], $_SESSION['player'], $_SESSION['deck']) = getNewHand();
}

// Set some flags we'll use later
$player_stands = false;
$end_game = false;

// If we weren't given acommand, assume we are given 'new'
if(!isset($_POST['command'])) {
	$command = 'new';
} else {
	$command = strtolower($_POST['command']);
}

// Figure out what command to do
switch($command) {
	// The player selected 'Stand'
	// Set the flag so we know to play out the dealer's hand
	case 'stand':
		$player_stands = true;
		break;
	// The player selected 'Hit', draw them another card 
	case 'hit':
		$_SESSION['player'][] = drawCard($_SESSION['deck']);
		break;
	// Reset the game back to a new deck and hand
	// Turn the flags back off
	case 'new':
		list($_SESSION['dealer'], $_SESSION['player'], $_SESSION['deck']) = getNewHand();
		$player_stands = false;
		$end_game = false;
		break;
}

// Calculate the hands of the player and dealer
$dealer_hand = calculateHandValue($_SESSION['dealer']);
$player_hand = calculateHandValue($_SESSION['player']);

// Did the player choose 'Stand'? If so, play out the dealer's hand
if($player_stands) {

	// The dealer must hit until he has 17 or better
	if($dealer_hand < 17) {
		do {
			$_SESSION['dealer'][] = drawCard($_SESSION['deck']);	
			$dealer_hand = calculateHandValue($_SESSION['dealer']);
		} while($dealer_hand < 17);
	}
	
	// Did the dealer and player push?
	if($dealer_hand == $player_hand) {
		print "<font color='red'><b>Push! Both players have $dealer_hand</b></font><br>";
	// Did the dealer beat the player without busting?
	} else if (($dealer_hand > $player_hand) && ($dealer_hand <= 21)) {
		print "<font color='red'><b>Dealer Wins with $dealer_hand!</b></font><br>";
	// The player wins!
	} else {
		print "<font color='red'><b>Player Wins with $player_hand!</b></font><br>";
	}
	
	$end_game = true;
}

// Figure out what message to display and set the flags based on the outcome
switch(true) {
	// Dealer busted, game over
	case ($dealer_hand > 21):
		print "<font color='red'><b>Dealer Busts</b></font><br>";
		$end_game = true;
		$player_stands = false;
		break;
	// Player busted, game over		
	case ($player_hand > 21):
		print "<font color='red'><b>Player Busts</b></font><br>";
		$end_game = true;
		$player_stands = false;
		break;
	// Special case, Both players had 21
	case (($dealer_hand == 21) && ($player_hand == 21)):
		print "<font color='red'><b>Push!</b></font><br>";
		$end_game = true;
		$player_stands = false;
		break;
	// Special case for if one of the hands == 21
	case (($dealer_hand == 21) || ($player_hand == 21)):
		
		// Check for Dealer Blackjack
		if($dealer_hand == 21) {
			if(count($_SESSION['dealer']) == 2) {
				print "<font color='red'><b>Dealer Wins! Dealer has Blackjack!</b></font><br>";
			} 
		// If it wasn't the dealer, it must have been the player
		} else {
			if(count($_SESSION['player']) == 2) {
				print "<font color='red'><b>Player Wins! Player has Blackjack!</b></font><br>";
			} 
		}
		$end_game = true;
		$player_stands = false;
		break;
}

// Display the output of the game, starting with the form buttons

print "<form method='post' action='{$_SERVER['PHP_SELF']}'>";

// If it is the end of the game don't display Hit/Stand as options
if(!$end_game) {
	print "<input type='submit' name='command' value='Hit'>&nbsp;
		   <input type='submit' name='command' value='Stand'>&nbsp;";
}

print "<input TYPE='submit' name='command' value='New'>&nbsp;</form>";

// Display the hands of the dealer and player
// We use the $end_game variable to determine if we should show the dealer's hand or not
displayCards($_SESSION['dealer'], $_SESSION['player'], $end_game);

